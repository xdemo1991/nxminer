{
	"total_khs": 346.3, //total hashrate, same as $khs
	"hs": [123, 223.3], //array of hashes
	"hs_units": "khs", //Optional: units that are uses for hashes array, "hs", "khs", "mhs", ... Default "khs".   
	"temp": [60, 63], //array of miner temps
	"fan": [80, 100], //array of miner fans
	"uptime": 12313232, //seconds elapsed from miner stats
	"ver": "1.2.3.4-beta", //miner version currently run, parsed from it's API or manifest

	//Optional: accepted, rejected shares.
	//2 numbers are required, you can add total invalids as 3rd number
	//4th array item can be string with invalids per gpu semicolon separated in order of bus_numbers, e.g. "0;1;0;5" where 5 is for 13th pci bus
	"ar": [123, 3, optional Invalids, "optional Invalids per GPU"],

	//Optional: algo used by miner, should one of the exiting in Hive
	"algo": "customalgo",

	//Pci buses array in decimal format. E.g. 0a:00.0 is 10
	"bus_numbers": [0, 1, 12, 13]
}
